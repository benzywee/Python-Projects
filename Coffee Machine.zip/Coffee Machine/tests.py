class Car:
    def __init__(self, model):
        self.model = model

    def drive(self):
        print("vroom vroom")

my_car = Car("Volkswagen")
Car.drive(Car("model"))

#skribbl.io
# from random import randint
#
# words = ["pika", "hodor", "putin", "salt", "chicken nuggets"]
# omit = []
# counter = 0
#
# while counter < 4:
#     random_word = words[randint(0, len(words)-1)]
#     if random_word in omit:
#         continue
#     else:
#         omit.append(random_word)
#         print(random_word)
#         counter += 1
