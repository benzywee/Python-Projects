class Dog:
    def __init__(self, name):
        self.name = name


pumpkin = Dog("Pumpkin")
