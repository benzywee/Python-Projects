class Student:

    def __init__(self, name, last_name, birth_year):
        self.name = name
        self.last_name = last_name
        self.birth_year = birth_year
        self.id = self.name[0] + self.last_name + self.birth_year


a, b, c = input(), input(), input()
create_id = Student(a, b, c)

print(create_id.id)
