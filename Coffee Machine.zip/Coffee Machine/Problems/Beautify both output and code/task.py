nickname, profession = input(), input()

print("http://example.com/{0}/desirable/{1}/profile".format(nickname, profession))
