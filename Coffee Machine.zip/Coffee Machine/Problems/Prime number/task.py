number = int(input())
prime = True

for num in range(1, number + 1):
    if number == 1:
        prime = False
        break
    if num in (1, number):
        continue
    if number % num == 0:
        prime = False
        break

if prime:
    print("This number is prime")
else:
    print("This number is not prime")
