a = int(input())
b = int(input()) + 1
counter = 0
total = 0

for num in range(a, b):
    if num % 3 == 0:
        counter += 1
        total += num

print(total / counter)
