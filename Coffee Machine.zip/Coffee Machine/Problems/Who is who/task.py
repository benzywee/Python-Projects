class Angel:
    color = "white"
    feature = "wings"
    home = "Heaven"


class Demon:
    color = "red"
    feature = "horns"
    home = "Hell"


good = Angel()
bad = Demon()

print(good.color)
print(good.feature)
print(good.home)

print(bad.color)
print(bad.feature)
print(bad.home)
