number = float(input())
round_to = int(input())

print(f"{number:.{round_to}f}")
