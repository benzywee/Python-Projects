word = input()
backwards = ""
counter = -1

for _char in word:
    backwards = backwards + word[counter]
    counter -= 1

if word == backwards:
    print("Palindrome")
else: 
    print("Not palindrome")
