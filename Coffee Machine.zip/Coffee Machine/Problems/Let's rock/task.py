class RockBand:
    genre = "rock"
    key_instruments = ["electric guitar", "drums"]
    n_members = 4


all_time_low = RockBand()

print(all_time_low.genre, all_time_low.n_members, all_time_low.key_instruments, sep="\n")
