number_1 = int(input())
number_2 = int(input())

if number_1 < number_2:
    print(number_2)
    print(number_1)
else:
    if number_1 == number_2:
        print(number_2)
        print(number_1)
    else:
        print(number_1)
        print(number_2)
