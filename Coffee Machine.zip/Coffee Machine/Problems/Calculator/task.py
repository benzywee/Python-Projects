first_number = float(input())
second_number = float(input())
operation = input()
text = ""

# usual ones
if operation == "+":
    text = first_number + second_number
elif operation == "-":
    text = first_number - second_number
elif operation == "*":
    text = first_number * second_number
elif operation == "/" and second_number != 0:
    text = first_number / second_number

# special operations
if operation == "mod" and second_number != 0:
    text = first_number % second_number
elif operation == "pow":
    text = first_number ** second_number
elif operation == "div" and second_number != 0:
    text = first_number // second_number

if second_number == 0 and operation in ["/", "mod", "div"]:
    text = "Division by 0!"

print(text)
