infinite = True
stop_taking_input = False
total = 0
numbers_to_count = []

while infinite:
    number = int(input())
    if not stop_taking_input:
        total = total + number
        numbers_to_count.append(number)
    if total == 0:
        squared_total = 0
        for i in numbers_to_count:
            squared_total = squared_total + (i ** 2)
        stop_taking_input = True
        print(squared_total)
        infinite = False
