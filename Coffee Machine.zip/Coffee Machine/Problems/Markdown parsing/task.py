text = input()
text = text.lstrip("*_~`").rstrip("*_~`")
print(text)
