class Painting:

    def __init__(self, title, painter, year):
        self.title = title
        self.painter = painter
        self.year = year
        print(f'"{self.title}" by {self.painter} ({self.year}) hangs in the Louvre.')


in_title = input()
in_painter = input()
in_year = int(input())

new_entry = Painting(in_title, in_painter, in_year)
