title = input()
director = input()
year = int(input())

print(f"{title} (dir. {director}) came out in {year}")
