loop_stop = False
total = 0
counter = 0

while not loop_stop:
    number = input()
    if number == ".":
        loop_stop = True
        break
    total = total + int(number)
    counter += 1

print(total / counter)
