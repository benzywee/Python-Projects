water, milk, beans, cups, money = 400, 540, 120, 9, 550


def final_statement():
    print("\nThe coffee machine has:\n"
          + str(water) + " of water\n"
          + str(milk) + " of milk\n"
          + str(beans) + " of coffee beans\n"
          + str(cups) + " of disposable cups\n"
          + str(money) + " of money\n")


final_statement()
action = input("Write action (buy, fill, take): \n> ")


def buy():
    product = int(input("What do you want to buy? 1 - espresso, 2 - latte, 3- cappuccino: \n> "))
    global water, milk, beans, cups, money
    if product == 1:  # espresso
        water -= 250
        beans -= 16
        money += 4
    elif product == 2:  # latte
        water -= 350
        milk -= 75
        beans -= 20
        money += 7
    elif product == 3:  # cappuccino
        water -= 200
        milk -= 100
        beans -= 12
        money += 6
    cups -= 1
    final_statement()


def fill():
    global water, milk, beans, cups, money
    water += int(input("Write how many ml of water do you want to add: \n> "))
    milk += int(input("Write how many ml of milk do you want to add: \n> "))
    beans += int(input("Write how many grams of coffee beans do you want to add: \n> "))
    cups += int(input("Write how many disposable cups of coffee do you want to add: \n> "))
    final_statement()


def take():
    global water, milk, beans, cups, money
    print("I gave you $" + str(money) + "\n")
    money -= money
    final_statement()


if action == "buy":
    buy()
elif action == "fill":
    fill()
elif action == "take":
    take()
