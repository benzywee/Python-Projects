class CoffeeMachine:
    water, milk, beans, cups, money = 400, 540, 120, 9, 550

    def __init__(self):
        self.get_action()

    def get_action(self):
        action = input("Write action (buy, fill, take, remaining, exit): \n> ")
        self.process_action(action)

    def process_action(self, action):
        if action == "buy":
            product = input("\nWhat do you want to buy? 1 - espresso, 2 - latte, 3- cappuccino: \n> ")
            self.buy(product)
        elif action == "fill":
            self.fill()
        elif action == "take":
            self.take()
        elif action == "remaining":
            self.remaining()
        elif action == "exit":
            self.end()

    def buy(self, product):
        can_make = True
        if product == "back":
            self.get_action()
        else:

            def check_resources(cost_water, cost_milk, cost_beans, cost_cups):
                nonlocal can_make
                if self.water < cost_water:
                    print("Sorry, not enough water!\n")
                    can_make = False
                if self.milk < cost_milk:
                    print("Sorry, not enough milk!\n")
                    can_make = False
                if self.beans < cost_beans:
                    print("Sorry, not enough coffee beans!\n")
                    can_make = False
                if self.cups < cost_cups:
                    print("Sorry, not enough disposable cups!\n")
                    can_make = False

            if product == "1":  # espresso
                check_resources(250, 0, 16, 1)
                if can_make:
                    print("I have enough resources, making you a coffee!\n")
                    self.water -= 250
                    self.beans -= 16
                    self.money += 4
            elif product == "2":  # latte
                check_resources(350, 75, 20, 1)
                if can_make:
                    print("I have enough resources, making you a coffee!\n")
                    self.water -= 350
                    self.milk -= 75
                    self.beans -= 20
                    self.money += 7
            elif product == "3":  # cappuccino
                check_resources(200, 100, 12, 1)
                if can_make:
                    print("I have enough resources, making you a coffee!\n")
                    self.water -= 200
                    self.milk -= 100
                    self.beans -= 12
                    self.money += 6
            if can_make:
                self.cups -= 1
            self.get_action()

    def fill(self):
        self.water += int(input("\nWrite how many ml of water do you want to add: \n> "))
        self.milk += int(input("Write how many ml of milk do you want to add: \n> "))
        self.beans += int(input("Write how many grams of coffee beans do you want to add: \n> "))
        self.cups += int(input("Write how many disposable cups of coffee do you want to add: \n> "))
        self.get_action()

    def take(self):
        print("I gave you $" + str(self.money) + "\n")
        self.money -= self.money
        self.get_action()

    def remaining(self):
        print("\nThe coffee machine has:\n"
              + str(self.water) + " of water\n"
              + str(self.milk) + " of milk\n"
              + str(self.beans) + " of coffee beans\n"
              + str(self.cups) + " of disposable cups\n"
              + "$" + str(self.money) + " of money\n")
        self.get_action()

    def end(self):
        pass


machine = CoffeeMachine()
