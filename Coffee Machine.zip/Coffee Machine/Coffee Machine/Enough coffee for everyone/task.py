water = int(input("Write how many ml of water the coffee machine has: \n > "))
milk = int(input("Write how many ml of milk the coffee machine has: \n > "))
beans = int(input("Write how many grams of coffee beans the coffee machine has: \n > "))
cups = int(input("Write how many cups of coffee you will need: \n > "))

if (cups * 200 > water) or (cups * 50 > milk) or (cups * 15 > beans):
    calculations = (water // 200, milk // 50, beans // 15)
    print("No, I can only make " + str(min(calculations)) + " cups of coffee")
else:
    water = water - cups * 200
    milk = milk - cups * 50
    beans = beans - cups * 15
    calculations = (water // 200, milk // 50, beans // 15)
    if min(calculations) > 0:
        print("Yes, I can make that amount of coffee (and even " + str(min(calculations)) + " more than that)")
    else:
        print("Yes, I can make that amount of coffee")
