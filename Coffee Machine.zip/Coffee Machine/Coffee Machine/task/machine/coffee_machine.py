total_cups = int(input("Write how many cups of coffee you will need: > "))
water, milk, coffee_beans = 200, 50, 15

print("For " + str(total_cups) + " cups of coffee you will need:"
      "\n" + str(water * total_cups) + " ml of water"
      "\n" + str(milk * total_cups) + " ml of milk"
      "\n" + str(coffee_beans * total_cups) + " g of coffee beans")