water, milk, beans, cups, money = 400, 540, 120, 9, 550
loop = True


def final_statement():
    print("\nThe coffee machine has:\n"
          + str(water) + " of water\n"
          + str(milk) + " of milk\n"
          + str(beans) + " of coffee beans\n"
          + str(cups) + " of disposable cups\n"
          + "$" + str(money) + " of money\n")


def buy():
    product = input("\nWhat do you want to buy? 1 - espresso, 2 - latte, 3- cappuccino: \n> ")
    while loop:
        if product == "back":
            break
        global water, milk, beans, cups, money
        can_make = True

        def check_resources(cost_water, cost_milk, cost_beans, cost_cups):
            nonlocal can_make
            if water < cost_water:
                print("Sorry, not enough water!\n")
                can_make = False
            if milk < cost_milk:
                print("Sorry, not enough milk!\n")
                can_make = False
            if beans < cost_beans:
                print("Sorry, not enough coffee beans!\n")
                can_make = False
            if cups < cost_cups:
                print("Sorry, not enough disposable cups!\n")
                can_make = False

        if product == "1":  # espresso
            check_resources(250, 0, 16, 1)
            if can_make:
                print("I have enough resources, making you a coffee!\n")
                water -= 250
                beans -= 16
                money += 4
        elif product == "2":  # latte
            check_resources(350, 75, 20, 1)
            if can_make:
                print("I have enough resources, making you a coffee!\n")
                water -= 350
                milk -= 75
                beans -= 20
                money += 7
        elif product == "3":  # cappuccino
            check_resources(200, 100, 12, 1)
            if can_make:
                print("I have enough resources, making you a coffee!\n")
                water -= 200
                milk -= 100
                beans -= 12
                money += 6
        if can_make:
            cups -= 1
        break


def fill():
    global water, milk, beans, cups, money
    water += int(input("Write how many ml of water do you want to add: \n> "))
    milk += int(input("Write how many ml of milk do you want to add: \n> "))
    beans += int(input("Write how many grams of coffee beans do you want to add: \n> "))
    cups += int(input("Write how many disposable cups of coffee do you want to add: \n> "))


def take():
    global water, milk, beans, cups, money
    print("I gave you $" + str(money) + "\n")
    money -= money


def remaining():
    final_statement()


while loop:
    action = input("Write action (buy, fill, take, remaining, exit): \n> ")
    if action == "buy":
        buy()
    elif action == "fill":
        fill()
    elif action == "take":
        take()
    elif action == "remaining":
        remaining()
    elif action == "exit":
        break
